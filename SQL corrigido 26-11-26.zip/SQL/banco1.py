import os

print(os.getcwd())
print(os.path.abspath("mb1.db")) # Teste

import sqlite3 

try:
    with sqlite3.connect("mb1.db") as banco: 
        banco.row_factory = sqlite3.Row
        cur = banco.cursor()
        busca = input("Digite parte do nome: ").strip()
        cur.execute("SELECT * FROM amigos WHERE nome LIKE ?",(f"%{busca}%",))
        # lista = cur.fetchall()
        # print(lista)

        total = 0
        for total, amigo in enumerate(cur, start = 1):
            print(f"{amigo['nome']} nasceu em {amigo['nascimento']}")

        print(f"Ao todo encontrei {total} amigos com '{busca}'")

except sqlite3.Error as erro:
    print(f"Falha no banco: {erro}")
except Exception as erro: 
    print(f"Algo deu errado: {erro}")

# Mostre uma mensagem caso nao seja encontrado registro
# Trate as datas imvalidas e vazias
# Mostre a data formatada
# Mostre a idade real da pessoa