class moeda():
    def __init__(self, valor, operaçao, variavel):
        self.valor = valor
        self.operaçao = operaçao
        self.variavel = variavel
        valor = int(input(" Qual o valor da sua moeda? "))
        operaçao = float(input(" Qual operação você deseja executar? "))
        variavel = int(input(" Por qual número? "))