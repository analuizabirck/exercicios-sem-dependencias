# importar a classe "moeda" -> ela deve ser renomeado.
# deixar o valor da moeda como monetário formatado (R$)
# obs: existe um comando que faz isso por você. -> 108
# crie um paâmetro a mais que informe se o valor retornado
# vai ser ou não formatado pela função 'moeda'. -> 109
# adicione uma funçâo chamada 'resumo' que mostre algumas
# das informações geradas pelas funções anteriores. -> 110
# crie um pacote chamado 'utilidadesCeV' que tenha dois módulos
# internos chamados moeda e dados, transfira as funções das
# questões 107-109 para o primeiro pacote e mantenha tudo
# funcionando. -> 110
# crie uma função chamada 'leiaDinheiro' que seja capaz de funcionar
# como a função 'input', mas com validação de dados para aceitar
# apenas valores monetários. -> 112


    def aumentar(self, soma, operaçao, variavel, valor):
        self.soma = soma
        if operaçao == 'soma':
            soma = valor + variavel
            print(f"O resultado será ${soma}")
        else:
            return "Digite um valor"

    def diminuir(self, subtraçao, operaçao, variavel, valor):
        self.subtraçao = subtraçao
        if operaçao == 'subtraçao':
            subtraçao = valor - variavel
            print(f"O resultado será ${subtraçao} ")
        return "Digite o valor"

    def dobro(self, multiplicaçao, operaçao, valor, variavel):
        self.multiplicaçao = multiplicaçao
        if operaçao == 'multiplicação':
            multiplicaçao = valor * variavel
            print(f"O resultado será ${multiplicaçao}")
        else:
            return "Digite um valor"

    def metade(self, divisao, operaçao, valor, variavel):
        self.divisao = divisao
        if operaçao == 'divisão':
            divisao = valor / variavel
            print(f" O resultado será ${divisao}")
        else:
            return "Digite um valor"