# preparar e servir são métodos herdados, já ferver agua e misturar são métodos próprios.
# 
#

class BebidasQuentes():
    def __init__(self):
        str(input("O que você deseja preparar: "))

    class cafe():
        def ferver_agua():

    class cha():
    class leite():
    