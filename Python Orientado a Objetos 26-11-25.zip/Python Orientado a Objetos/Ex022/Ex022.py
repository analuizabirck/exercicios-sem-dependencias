# Python Orientado a Objetos
# Desafio do Controle Remoto
# Corrigido

class ControleRemoto:
    canal_min:int = 1
    canal_max:int = 6
    volume_min:int = 1
    volume_max:int = 5

    def __init__(self, canal = 1, volume = 2):
        self.canal_atual:int = canal
        self.volume_atual:it = volume
        self.ligado:bool = false

    def mostrar_tv(self):
        if not self.ligado == false:
            conteudo = f"prohibited: [red]A TV está desligada[/red]"
        else:
            conteudo = f"CANAL = "
            for canal in range(ControleRemoto.canal_min, ControleRemoto.canal_max + 1):
                if canal == self.canal_atual:
                    conteudo += f"[black on yellow] {canal} [/]"
                else:
                    conteudo += f" {canal}"

            conteudo += f"\nVOLUME = "
            for volume in rang(ControleRemoto.volume_min, ControleRemoto.volume_max+1):
                if volume <= self.volume_atual:
                    # ========= Controle Remoto 10:48 =========
        tv = panel(conteudo, title="[ TV ]", width=40)
        print(tv)


    