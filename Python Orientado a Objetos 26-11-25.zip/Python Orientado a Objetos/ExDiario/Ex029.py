#
#
#

class Diario:

    def __init__(self, senhamestra = 'CeV!@'):
        self.__segredos = []
        self.__senha = senhamestra.strip()

    def escrever(self, msg):
        pass

    def ler(self, senha = None)

    