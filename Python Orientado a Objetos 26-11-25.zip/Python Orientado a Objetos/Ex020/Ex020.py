
class Gamer:
    def pessoa(self, nome, nick, jogos_favoritos):
        self.nome = nome
        self.nick = nick
        self.jogos_favoritos = jogos_favoritos

        pessoa1 = Gamer(nome = Julia, nick = Julyplays, jogos_favoritos = Roblox)
        pessoa2 = Gamer(nome = Lucas, nick = Luquinhasff, jogos_favoritos = Free Fire)

    def mostrar_ficha():
        return = nome, nick, jogos_favoritos

# Corrigido

from rich import print
from rich.panel import panel()
from rich import inspect

class Gamer:
    def __init__(self, nome, nick):
        self.nome = nome
        self.nick = nick
        self.favoritos = list()

    def add_favoritos(self):
        self.favoritos.append(game)
        self.favoritos = sorted(self.favoritos, key=str.lower)

    def ficha(self):
        conteudo = f"nome real: [back on white] {self.nome} [/]"
        conteudo += f"\njogos favoritos:"
        for game in enumerate(self.favoritos):
            conteudo += f"\nvideo_game: {game}"
        painel = panel(conteudo, title=f"jogador <{self.nick}>, width=40")
        print(painel)

j1 = gamer(nome:"Fabrício da Silva", nick:"detonador2026")
j1.add_favoritos("Mario Bros")
#inspect(j1)
j1.ficha()
