# Crie classes capazes de calcular fretes de veículos diferentes.
# Transporte: Moto, Caminhão e Drone.
# Cada veículo deve haver  

class Transporte:
    def __init__(self, dist, frete):
        self.dist = dist
        self.frete = frete
        str(input(" "))

    def calc_frete(self):
        self.frete * self.fator

    class Moto:
        def __init__(self, fator):
            self.fator = fator
            fator = 0.50
        

    class Caminhao:
        def __init__(self, fator):
            self.fator = fator
            fator = 1.20
        

    class Drone:
        def __init__(self, fator):
            self.fator = fator
            fator = 9.50

    Moto = calc_frete()
    Caminhao = calc_frete()
    Drone = calc_frete()

    
