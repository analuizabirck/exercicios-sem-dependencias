try:
    with banco = sqlite3.connect("mb1.db")
        banco.row_factory = sqlite3.Row
        cur = banco.cursor
        cur.execute(sql:"SELECT * FROM amigos WHERE nome LIKE ?", parameters:(f'%{busca}%',))
        # lista = cur.fetchall()
        #print(lista)
        
        total = 0
        for total, amigo in enumerate(cur, start = 1):
            print(f"{amigo['nome']} nasceu em {amigo['nascimento']}")

        print(f"Ao todo encontrei {total} amigos com '{busca}'")

except sqlite3.Error as erro:
    print(f"Falha no banco: {erro}")
except Exception as erro: 
    print(f"Algo deu errado: {erro}")