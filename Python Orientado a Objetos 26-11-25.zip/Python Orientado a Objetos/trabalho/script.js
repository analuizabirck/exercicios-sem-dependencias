function selecionar() {
}

function clicarSecao1() {
    document.getElementById("secao1").classList.add("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = `
    <p>
    O Funcionalismo é uma corrente das Ciências Sociais que entende a sociedade como um todo formado por partes interdependentes. Essas partes podem ser instituições, normas, valores, grupos e diferentes formas de organização social. Cada uma delas exerce uma ou mais funções e, juntas, contribuem para a manutenção e integração da sociedade.
    </p>
    `;
}
function clicarSecao2() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.add("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 2";
}
function clicarSecao3() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.add("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 3";
}
function clicarSecao4() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.add("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 4";
}
function clicarSecao5() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.add("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 5";
}
function clicarSecao6() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.add("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 6";
}
function clicarSecao7() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.add("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 7";
}
