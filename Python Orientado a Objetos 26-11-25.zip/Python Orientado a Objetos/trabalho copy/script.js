function selecionar() {
}

function clicarSecao1() {
    document.getElementById("secao1").classList.add("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 1";
}
function clicarSecao2() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.add("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");
    document.getElementById("secao8").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 2";
}
function clicarSecao3() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.add("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 3";
}
function clicarSecao4() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remover("selecionar");
    document.getElementById("secao4").classList.add("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 4";
}
function clicarSecao5() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.add("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 5";
}
function clicarSecao6() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.add("selecionar");
    document.getElementById("secao7").classList.remove("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 6";
}
function clicarSecao7() {
    document.getElementById("secao1").classList.remove("selecionar");
    document.getElementById("secao2").classList.remove("selecionar");
    document.getElementById("secao3").classList.remove("selecionar");
    document.getElementById("secao4").classList.remove("selecionar");
    document.getElementById("secao5").classList.remove("selecionar");
    document.getElementById("secao6").classList.remove("selecionar");
    document.getElementById("secao7").classList.add("selecionar");

    document.getElementById("conteudo").innerHTML = "Texto da seção 7";
}
const lateral =
document.querySelector("#lateral");
const arrastar =
document.querySelector("#arrastar");
let arrastando = false;

arrastar.addEventLiestener("mousedown"), () =>
{
    arrastando = true;
};
cocument.addEventListener("mouseup"), () =>{
    arrastando = false;
};
document.addEventListener("mousemove"),
(event) => {
    if (!arrastando) return;
    let largura = event.clientX;
    if (largura < 50) largura = 50;
    if (largura > window.innerWidth) largura =
    window.innerWidth;
    menubar.style.width = `{largura}px`
};
